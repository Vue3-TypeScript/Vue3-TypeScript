<template>
  <div class="overview">
    <h2>overview 核心技术</h2>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
