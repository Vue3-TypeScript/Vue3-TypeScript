<template>
  <div class="category">
    <h2>category</h2>
  </div>
</template>
