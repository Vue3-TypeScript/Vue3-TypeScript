<template>
  <div class="goods">
    <h2>goods</h2>
  </div>
</template>
