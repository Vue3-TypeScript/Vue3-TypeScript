import HyBreadcrumb from './src/breadcrumb.vue'
export * from './types' // 导出类型
export default HyBreadcrumb // 导出组件
