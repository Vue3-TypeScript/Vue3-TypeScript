import HyForm from './src/form.vue'
export * from './types'
export default HyForm
