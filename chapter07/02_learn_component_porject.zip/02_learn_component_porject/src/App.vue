<template>
  <div class="app">
    这是项目的模板。运行该项目：npm install , 然后npm run serve
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
.app{

}
</style>
