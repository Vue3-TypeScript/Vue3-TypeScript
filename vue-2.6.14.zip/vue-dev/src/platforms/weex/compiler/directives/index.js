import model from './model'

export default {
  model
}
