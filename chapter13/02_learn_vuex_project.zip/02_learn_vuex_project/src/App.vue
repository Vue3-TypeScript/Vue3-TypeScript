<template>
  <div>Welcome to Your Vue.js App</div>
</template>

<script>

export default {
  name: 'App',
  components: {
  }
}
</script>

<style>

</style>
